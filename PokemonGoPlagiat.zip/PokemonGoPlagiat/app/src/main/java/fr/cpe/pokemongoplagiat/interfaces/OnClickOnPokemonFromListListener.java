package fr.cpe.pokemongoplagiat.interfaces;

import fr.cpe.pokemongoplagiat.models.Pokemon;

public interface OnClickOnPokemonFromListListener {
    void onClickOnNote(Pokemon pokemon);
}
