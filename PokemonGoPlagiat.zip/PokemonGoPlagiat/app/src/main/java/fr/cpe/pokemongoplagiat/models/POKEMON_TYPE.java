package fr.cpe.pokemongoplagiat.models;

public enum POKEMON_TYPE {
    Acier,
    Combat,
    Dragon,
    Eau,
    Electrique,
    Fee,
    Feu,
    Glace,
    Insecte,
    Normal,
    Plante,
    Poison,
    Psy,
    Roche,
    Sol,
    Spectre,
    Tenebre,
    Vol
}