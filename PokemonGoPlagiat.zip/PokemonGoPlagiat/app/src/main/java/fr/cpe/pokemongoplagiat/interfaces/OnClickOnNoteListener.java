package fr.cpe.pokemongoplagiat.interfaces;

public interface OnClickOnNoteListener{
    void onClickOnNote(long noteId);
}
