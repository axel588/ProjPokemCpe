package fr.cpe.pokemongoplagiat.interfaces;

public interface OnClickOnMenuListener {
    void onClickOnItem(int index);
}
